<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../Assets/img/favicon.png" rel="icon">
    <title>404 Not Found</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 40px;
            text-align: center;
        }

        h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        p {
            font-size: 18px;
            margin-bottom: 30px;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="container">
        <a href="../" class="navbar-brand">
            <img src="../Assets/img/saafwanLogo.png" alt="saafwan" width="200">
        </a>
        <h1>Oops! 404 Not Found</h1>
        <p>The page you are looking for does not exist.</p>
        <p>Return to the <a href="../">homepage</a> or contact our <a href="http://reyad.ezyro.com/">support team</a> for assistance.</p>
    </div>
</body>

</html>